ssh -x c455-071.stampede3.tacc.utexas.edu /scratch/05598/fnetsch/tapis/043b7b6f-fc35-4194-9229-8778dce82da5-007/inputDirectory/simulation_constrained.linear.plate2/exec-gdb-c455-071.stampede3.tacc.utexas.edu.sh

