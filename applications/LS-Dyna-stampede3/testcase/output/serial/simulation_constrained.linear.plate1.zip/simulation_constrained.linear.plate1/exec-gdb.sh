ssh -x c454-093.stampede3.tacc.utexas.edu /scratch/05598/fnetsch/tapis/355e28de-0c4e-447d-8551-63c312fa6c7c-007/inputDirectory/simulation_constrained.linear.plate1/exec-gdb-c454-093.stampede3.tacc.utexas.edu.sh

